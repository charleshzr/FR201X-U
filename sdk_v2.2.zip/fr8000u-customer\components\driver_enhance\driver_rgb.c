/*
  ******************************************************************************
  * @file    driver_rgb.c
  * @author  FreqChip Firmware Team
  * @version V1.0.0
  * @date    2021
  * @brief   rgb module driver.
  *          This file provides firmware functions to manage the 
  *          Liquid Crystal Display peripheral.
  *          Support rgb interface.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2021 FreqChip.
  * All rights reserved.
  ******************************************************************************
*/
#include "driver_rgb.h"

/*********************************************************************
 * @fn      rgb_init
 *
 * @brief   Initialize the RGB according to the specified parameters
 *          in the RGB_Init 
 *
 * @param   hdma : pointer to a RGB_Init structure that contains
 *                 the configuration information for RGB module
 *          
 * @return  None.
 */
void rgb_init(RGB_InitTypeDef *RGB_Init)
{
    /* FIFO_RST */    
    __RGB_TX_FIFO_RESET();
    
    /* config RGB DMA */        
    __RGB_DMA_TX_LEVEL(16);
    __RGB_DMA_ENABLE();    
  
    /* set RGB Pixel Clk polarity*/
    __RGB_SET_PIXEL_CLK_DIV(RGB_Init->PixelClock_Prescaler);

    /* select RGB Out Format*/
    RGB->RGB_CFG.RGB_FORAMAT_OUT = RGB_Init->RGB_OUT_FORMAT_SELECT;
    /* select RGB In Format*/
    RGB->RGB_CFG.RGB_FORMAT_IN = RGB_Init->RGB_IN_FORMAT_SELECT;

    /* set VSYNC and HSYNC synchronous pulse width*/
    RGB->DISPLAY_PERIOD.VSPW = RGB_Init->VSPW - 1;
    RGB->DISPLAY_PERIOD.HSPW = RGB_Init->HSPW - 1;
    /* set VSYNC and HSYNC resolution */
    RGB->DISPLAY_PERIOD.HRES = RGB_Init->HRES - 1;  
    RGB->DISPLAY_PERIOD.VRES = RGB_Init->VRES - 1;   
    /* set VSYNC and HSYNC synchronize the following edge period */
    RGB->PORCH_PERIOD.HBP = RGB_Init->HBP - 1;  
    RGB->PORCH_PERIOD.VBP = RGB_Init->VBP - 1;
    /* set VSYNC and HSYNC synchronize the leading edge cycle */
    RGB->PORCH_PERIOD.HFP = RGB_Init->HFP - 1;
    RGB->PORCH_PERIOD.VFP = RGB_Init->VFP - 1;
    
    /* FIFO_RELEASE */
    __RGB_TX_FIFO_RELEASE();
}

/*********************************************************************
 * @fn      rgb_write_data
 *
 * @brief   Sending data or parameters
 *
 * @param   RGB_Init   : pointer to a RGB_InitTypeDef structure that contains
 *                       the configuration information for RGB module
 * @param   fp32_WriteBuffer : Write data buffer
 * @param   fu32_WriteNum    : transmit number.
 */
void rgb_write_data(RGB_InitTypeDef *RGB_Init, void *fp32_WriteBuffer, uint32_t fu32_WriteNum)
{   
    union {
        void *data;
        uint8_t *p_u8;
        uint16_t *p_u16;
        uint32_t *p_u32;
    } p_data;
    
    p_data.data = fp32_WriteBuffer;
    
    __RGB_ENABLE(); 
    
    if(RGB_Init->RGB_OUT_FORMAT_SELECT == RGB565_OUT)
    {
        while(fu32_WriteNum--)
        {
            while((__RGB_FIFO_STATUS()&TXFIFO_FULL));
            
            RGB->TX_FIFO = *p_data.p_u16++;
        }        
    }
    else
    {
        while(fu32_WriteNum--)
        {
            while((__RGB_FIFO_STATUS()&TXFIFO_FULL));
            
            RGB->TX_FIFO = *p_data.p_u32++;
        }  
    } 
    
    while(!(__RGB_FIFO_STATUS() & TXFIFO_EMPT));    
}
