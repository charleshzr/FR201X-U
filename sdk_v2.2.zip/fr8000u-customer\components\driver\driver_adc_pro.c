/*
  ******************************************************************************
  * @file    driver_adc_pro.c
  * @author  FreqChip Firmware Team
  * @version V1.0.0
  * @date    2025
  * @brief   ADC advanced controller module driver.
  *          This file provides firmware functions to manage the 
  *          Analog to Digital Converter (ADC) peripheral.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 FreqChip.
  * All rights reserved.
  ******************************************************************************
*/
#include "driver_adc_pro.h"


/******************************************************************************
 * @fn      saradc_init
 *
 * @brief   Initialize the SARADC according to the specified parameters
 *          in the saradc_InitConfig_t. 
 *
 * @param   Init : saradc_InitConfig_t structure that contains the
 *                 configuration information for SARADC module.
 */
void saradc_init(saradc_InitConfig_t *Init)
{
    /* power on ADC module */
    pmu_adc_power_control(true);
    /* controller select ADC pro */
    __SARADC_CONTROLLER_SELECT_ADCP();
    /* saradc power */
    __SARADC_ANA_POWER_ON();
    __SARADC_ANA_RESET_SET();
    __SARADC_ANA_RESET_RELEASE();
    while(__SARADC_IS_ANA_RESET());
    /* clock out to analog */
    __SARADC_CLK_ENABLE();
    /* saradc reset */
    __SARADC_RESET();
    __SARADC_FIFO_RESET();

    __SARADC_ANA_SOC_POLARITY_CONFIG(1);
    __SARADC_ANA_EOC_POLARITY_CONFIG(1);
    __SARADC_ANA_PIN_TO_SAMPLE_EN_CONFIG(1);
    __SARADC_ANA_PIN_TO_SAMPLE_EN_IO_CONFIG(1);

    /* saradc clock divider */
    if (Init->saradc_clock_div > 254)
        __SARADC_SAMPLING_CLOCK_DIV_CONFIG(256/2);
    else if (Init->saradc_clock_div >= 2)
        __SARADC_SAMPLING_CLOCK_DIV_CONFIG(Init->saradc_clock_div/2);
    else 
        __SARADC_SAMPLING_CLOCK_DIV_CONFIG(0);
    /* timeout set */
    __SARADC_SAMPLING_TIMEOUT_CONFIG(8);
    __SARADC_CONVERT_TIMEOUT_CONFIG(0xF);

    /* loop mode config */
    __SARADC_WORK_MODE();
    __SARADC_LOOP_MODE_CONFIG(0);

    /* Timing */
    if (Init->saradc_sampling_cycle > 15)
        __SARADC_ANA_SAMPLING_TIME_CONFIG(0xF);
    else if (Init->saradc_sampling_cycle > 4)
        __SARADC_ANA_SAMPLING_TIME_CONFIG(Init->saradc_sampling_cycle - 1);
    else
        __SARADC_ANA_SAMPLING_TIME_CONFIG(3);

    /* reference */
    __SARADC_ANA_REF_SEL_CONFIG(Init->saradc_reference);
    if (Init->saradc_reference == SARADC_REF_INTERNAL_1P2V)
    {
        __SARADC_ANA_REF_BUF_EN_CONFIG(1);
    }

    /* dynamic config */
    __SARADC_CLOCK_DYNAMIC_CONFIG(0);    // clock dynamic enable.
    __SARADC_CHP_DYNAMIC_CONFIG(0);      // channel dynamic enable.
    __SARADC_CHN_DYNAMIC_CONFIG(0);      // channel dynamic enable.
    __SARADC_SF_DYNAMIC_CONFIG(0);       // soft follow dynamic enable.
    __SARADC_DIFF_DYNAMIC_CONFIG(0);     // difference dynamic enable.
    __SARADC_ATT_DYNAMIC_CONFIG(0);      // voltage divider dynamic enable
    __SARADC_REF_DYNAMIC_CONFIG(1);      // reference source dynamic disable.
}

/******************************************************************************
 * @fn      saradc_loop_config
 *
 * @brief   loop mode config
 *
 * @param   sConfig : saradc_LoopModeConfig_t structure that contains the
 *                    configuration information for SARADC loop mode.
 */
bool saradc_loop_config(saradc_LoopConfig_t *sConfig)
{
    /* loop mode max channel */
    if (sConfig->loop_max_channel != 0)
        __SARADC_LOOP_MODE_MAX_CHANNEL_CONFIG(sConfig->loop_max_channel - 1);
    /* loop mode interval */
    if (sConfig->loop_interval_mode){
        __SARADC_INTV_MODE(sConfig->loop_interval_mode - SARADC_INTVL_MODE0);
        __SARADC_CHANNEL_INTERVAL_LENGTH_CONFIG(sConfig->loop_interval_len);
    }
    else{
        __SARADC_CHANNEL_INTERVAL_LENGTH_CONFIG(0);
    }

    if (sConfig->loop_FIFO_enable)
    {
        /* FIFO,DMA config */
        __SARADC_FIFO_ENABLE();
        if (sConfig->loop_FIFO_channel_sel >= 16){
            __SARADC_FIFO_MODE_CONFIG(1);// Select all loop channel
        }
        else{
            __SARADC_FIFO_MODE_CONFIG(0);// Select a specified channel
            __SARADC_FIFO_SELECT_CHANNEL_CONFIG(sConfig->loop_FIFO_channel_sel);
        }

        if (sConfig->loop_FIFO_almost_threshold >= 63)
            __SARADC_FIFO_ALMOST_FULL_THRESHOLD_CONFIG(63);
        else
            __SARADC_FIFO_ALMOST_FULL_THRESHOLD_CONFIG(sConfig->loop_FIFO_almost_threshold - 1);

        __SARADC_DMA_ENABLE();
    }
    else
    {
        __SARADC_FIFO_DISABLE();
        __SARADC_DMA_DISABLE();
    }

    return 0;
}

/******************************************************************************
 * @fn      saradc_loop_convert_start/stop
 *
 * @brief   loop mode hardware trigger start/stop. 
 */
void saradc_loop_convert_start(void)
{
    __SARADC_LOOP_CONVERT_START();
}
void saradc_loop_convert_stop(void)
{
    __SARADC_LOOP_CONVERT_STOP();
}


/******************************************************************************
 * @fn      saradc_wdt_config
 *
 * @brief   saradc wdt config.
 * 
 * @param   fe_wdt : saradc wdt select.
 * @param   sConfig : saradc wdt config info.
 */
void saradc_wdt_config(enum_saradc_wdt_t fe_wdt, saradc_WdtConfig_t *sConfig)
{
    if (fe_wdt == SARADC_WDT0)
    {
        /* saradc wdt mode config */
        __SARADC_WDT0_MODE_CONFIG(sConfig->saradc_WDT_mode);
        /* saradc wdt monitor channel config */
        __SARADC_WDT0_MONITOR_CHANNEL_CONFIG(sConfig->saradc_WDT_monitor_channel);
        /* saradc wdt channel trigger threshold */
        if (sConfig->saradc_WDT_trigger_threshold == 0)
            __SARADC_WDT0_TRIGGER_THRESHOLD_CONFIG(1);
        else if (sConfig->saradc_WDT_trigger_threshold <= 24)
            __SARADC_WDT0_TRIGGER_THRESHOLD_CONFIG(sConfig->saradc_WDT_trigger_threshold);
        else
            __SARADC_WDT0_TRIGGER_THRESHOLD_CONFIG(24);
        /* saradc wdt min/max limit value */
        __SARADC_WDT0_MIN_LIMIT_CONFIG(sConfig->saradc_WDT_min_limit);
        __SARADC_WDT0_MAX_LIMIT_CONFIG(sConfig->saradc_WDT_max_limit);
    }
    else
    {
        /* saradc wdt mode config */
        __SARADC_WDT1_MODE_CONFIG(sConfig->saradc_WDT_mode);
        /* saradc wdt monitor channel config */
        __SARADC_WDT1_MONITOR_CHANNEL_CONFIG(sConfig->saradc_WDT_monitor_channel);
        /* saradc wdt channel trigger threshold */
        if (sConfig->saradc_WDT_trigger_threshold == 0)
            __SARADC_WDT1_TRIGGER_THRESHOLD_CONFIG(1);
        else if (sConfig->saradc_WDT_trigger_threshold <= 24)
            __SARADC_WDT1_TRIGGER_THRESHOLD_CONFIG(sConfig->saradc_WDT_trigger_threshold);
        else
            __SARADC_WDT1_TRIGGER_THRESHOLD_CONFIG(24);
        /* saradc wdt min/max limit value */
        __SARADC_WDT1_MIN_LIMIT_CONFIG(sConfig->saradc_WDT_min_limit);
        __SARADC_WDT1_MAX_LIMIT_CONFIG(sConfig->saradc_WDT_max_limit);
    }
}

/******************************************************************************
 * @fn      saradc_wdt_enable/disable
 *
 * @brief   get the number of data in the fifo.
 */
void saradc_wdt_enable(enum_saradc_wdt_t fe_wdt)
{
    if (fe_wdt == SARADC_WDT0)
        __SARADC_WDT0_ENABLE();
    else
        __SARADC_WDT1_ENABLE();
}
void saradc_wdt_disable(enum_saradc_wdt_t fe_wdt)
{
    if (fe_wdt == SARADC_WDT0)
        __SARADC_WDT0_DISABLE();
    else
        __SARADC_WDT1_DISABLE();
}

/******************************************************************************
 * @fn      saradc_get_fifo_count
 *
 * @brief   get the number of data in the fifo.
 */
uint16_t saradc_get_fifo_count(void)
{
    return __SARADC_GET_FIFO_COUNT();
}
/******************************************************************************
 * @fn      saradc_get_fifo_data
 *
 * @brief   get data in the fifo.
 */
void saradc_get_fifo_data(uint16_t *fp_data, uint32_t fu32_length)
{
    while(fu32_length--)
    {
        *fp_data++ = __SARADC_GET_FIFO_DATA();
    }
}

/******************************************************************************
 * @fn      adc_get_channel_valid_status
 *
 * @brief   get Channel valid status.
 * 
 * @param   fe_channel : channel number(0 ~ 15)
 */
bool saradc_get_channel_valid_status(enum_saradc_channel_t fe_channel)
{
    return (__SARADC_GET_CHANNEL_VALID_STATUS() & (1 << fe_channel)) ? true : false;
}

/******************************************************************************
 * @fn      saradc_get_channel_data
 *
 * @brief   get logic Channel convert Data.
 * @param   fe_channel : channel number(0 ~ 15)
 */
uint16_t saradc_get_channel_data(enum_saradc_channel_t fe_channel)
{
    return __SARADC_GET_CHANNEL_DATA(fe_channel);
}

/******************************************************************************
 * @fn      saradc_channel_config
 *
 * @brief   logic Channel config.
 * @param   fe_channel : channel number(0 ~ 15)
 * @param   sConfig    : saradc channel config info.
 */
void saradc_channel_config(enum_saradc_channel_t fe_channel, saradc_ChannelConfig_t *sConfig)
{
    /* channel mode */
    __SARADC_CHANNEL_MODE_CONFIG(fe_channel, sConfig->ch_mode);
    /* channel voltage divider */
    __SARADC_CHANNEL_ATT_CONFIG(fe_channel, sConfig->ch_voltage_divider);
    /* channel source follower */
    __SARADC_CHANNEL_SOURCE_FOLLOWER_CONFIG(fe_channel, sConfig->ch_source_follower_en);
    /* channel mapping */
    if (sConfig->ch_mode)
    {
        __SARADC_CHANNEL_MAP_P_CONFIG(fe_channel, sConfig->ch_map_p);
        __SARADC_CHANNEL_MAP_N_CONFIG(fe_channel, sConfig->ch_map_n);
    }
    else
    {
        __SARADC_CHANNEL_MAP_P_CONFIG(fe_channel, sConfig->ch_map_p);
        __SARADC_CHANNEL_MAP_N_CONFIG(fe_channel, ADC_CH_MAP_VSSA);
    }
}

/******************************************************************************
 * @fn      saradc_vbe_measure_enable/disable
 *
 * @brief   The vbe measurement circuit enable.
 */
void saradc_vbe_measure_enable(void)
{
    __SARADC_ANA_TEMP_SENSE_EN_CONFIG(1);
}
void saradc_vbe_measure_disable(void)
{
    __SARADC_ANA_TEMP_SENSE_EN_CONFIG(0);
}

/******************************************************************************
 * @fn      saradc_vbat_measure_enable/disable
 *
 * @brief   The vbat measurement circuit enable and config vbat divider.
 * @param   fe_VbatCfg : vbat divider select.
 */
void saradc_vbat_measure_enable(void)
{
    __SARADC_ANA_VBAT_DIV_EN_CONFIG(1);
}
void saradc_vbat_measure_disable(void)
{
    __SARADC_ANA_VBAT_DIV_EN_CONFIG(0);
}

/*********************************************************************
 * @fn      saradc_int_enable/disable
 *
 * @brief   enable/disable saradc interrupt.
 * 
 * @param   fu32_INT: saradc interrupt index, @ref SARADC_interrupt_enable_definition
 *          This parameter can be one of the following values:
 *          @arg SARADC_INT_EN_CHANNEL_VALID: channel valid interrupt.
 *          @arg SARADC_INT_EN_LOOP: loop interrupt.
 *          @arg SARADC_INT_EN_WDT0: watchdog0 interrupt.
 *          @arg SARADC_INT_EN_WDT1: watchdog1 interrupt.
 *          @arg SARADC_INT_EN_FIFO_ALMOST_FULL: FIFO almost full interrupt.
 *          @arg SARADC_INT_EN_FIFO_EMPTY: FIFO empty interrupt.
 *          @arg SARADC_INT_EN_FIFO_FULL:  FIFO full interrupt.
 *          @arg SARADC_INT_EN_CONVERT_ERR: convert error interrupt.
 */
void saradc_int_enable(uint32_t fu32_INT)
{
    __SARADC_INT_ENABLE(fu32_INT);
}
void saradc_int_disable(uint32_t fu32_INT)
{
    __SARADC_INT_DISABLE(fu32_INT);
}

/*********************************************************************
 * @fn      saradc_int_status_clear
 *
 * @brief   clear saradc interrupt.
 * 
 * @param   fu32_INT: saradc interrupt index, @ref SARADC_interrupt_clear_status_definition
 *          This parameter can be one of the following values:
 *          @arg SARADC_INT_STS_CLR_LOOP: clear loop interrupt status.
 *          @arg SARADC_INT_STS_CLR_WDT0: clear watchdog0 interrupt status.
 *          @arg SARADC_INT_STS_CLR_WDT1: clear watchdog1 interrupt status.
 *          @arg SARADC_INT_STS_CLR_CONVERT_ERR: clear convert error interrupt status.
 */
void saradc_int_status_clear(uint32_t fu32_INT)
{
    __SARADC_CLR_INT_STATUS(fu32_INT);
}

/******************************************************************************
 * @fn      saradc_get_int_status
 *
 * @brief   saradc get interrupt status.(int Enbale & int raw status)
 * 
 * @return  interrupt status.
 *          interrupt status can be one of the following values:
 *          @arg SARADC_INT_STS_CHANNEL_VALID: channel valid interrupt.
 *          @arg SARADC_INT_STS_LOOP: loop interrupt.
 *          @arg SARADC_INT_STS_WDT0: watchdog0 interrupt.
 *          @arg SARADC_INT_STS_WDT1: watchdog1 interrupt.
 *          @arg SARADC_INT_STS_FIFO_ALMOST_FULL: FIFO almost full interrupt.
 *          @arg SARADC_INT_STS_FIFO_FULL:  FIFO full interrupt.
 *          @arg SARADC_INT_STS_FIFO_EMPTY: FIFO empty interrupt.
 *          @arg SARADC_INT_STS_CONVERT_ERR: convert error interrupt.
 */
uint32_t saradc_get_int_status(void)
{
    return __SARADC_GET_INT_STATUS();
}

/******************************************************************************
 * @fn      saradc_get_int_raw_status
 *
 * @brief   saradc get interrupt raw status.
 * 
 * @return  raw status.
 *          raw status can be one of the following values:
 *          @arg SARADC_INT_RAW_STS_CHANNEL_VALID: channel valid interrupt.
 *          @arg SARADC_INT_RAW_STS_LOOP: loop interrupt.
 *          @arg SARADC_INT_RAW_STS_WDT0: watchdog0 interrupt.
 *          @arg SARADC_INT_RAW_STS_WDT1: watchdog1 interrupt.
 *          @arg SARADC_INT_RAW_STS_FIFO_ALMOST_FULL: FIFO almost full interrupt.
 *          @arg SARADC_INT_RAW_STS_FIFO_FULL:  FIFO full interrupt.
 *          @arg SARADC_INT_RAW_STS_FIFO_EMPTY: FIFO empty interrupt.
 *          @arg SARADC_INT_RAW_STS_CONVERT_ERR: convert error interrupt.
 */
uint32_t saradc_get_int_raw_status(void)
{
    return __SARADC_GET_INT_RAW_STATUS();
}
