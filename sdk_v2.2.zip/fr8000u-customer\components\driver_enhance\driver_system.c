#include <stdbool.h>

#include "jump_table.h"

#include "driver_system.h"

/*********************************************************************
 * @fn      system_delay_us
 *
 * @brief   system delay unit us, use system free counter.
 *
 * @param   fu32_delay: delay unit us.
 */
__attribute__((section("ram_code"))) void system_delay_us(uint32_t fu32_delay)
{
    uint32_t backups_tack = FREE_COUNTER_US;

    while(backups_tack - FREE_COUNTER_US < fu32_delay);
}
