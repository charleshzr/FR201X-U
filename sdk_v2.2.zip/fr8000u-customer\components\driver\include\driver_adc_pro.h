/*
  ******************************************************************************
  * @file    driver_adc_pro.h
  * @author  FreqChip Firmware Team
  * @version V1.0.0
  * @date    2025
  * @brief   Header file of adc_pro HAL module.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 FreqChip.
  * All rights reserved.
  ******************************************************************************
*/
#ifndef __DRIVER_ADC_PRO_H__
#define __DRIVER_ADC_PRO_H__

#include "stdint.h"
#include "stdbool.h"

#include "driver_pmu.h"

/** @addtogroup ADC_Pro_Registers_Section
  * @{
  */
/* ################################ Register Section Start ################################ */

/* Control Register for SARADC */
typedef struct
{
    uint32_t SARADC_LoopEn     : 1;
    uint32_t SARADC_ClkEn      : 1;
    uint32_t SARADC_Reset      : 1;
    uint32_t SARADC_FIFO_Reset : 1;
    uint32_t rsv_0             : 27;
    uint32_t SARADC_ctrl_sel   : 1;
}REG_SARADC_Control_t;

/* Config Register for SARADC */
typedef struct
{
    uint32_t SARADC_OP_Mode          : 1;
    uint32_t SARADC_POLL_Mode        : 1;
    uint32_t SARADC_Intv_Mode        : 1;
    uint32_t SARADC_FIFO_En          : 1;
    uint32_t SARADC_DMA_En           : 1;
    uint32_t SARADC_ANA_SOCPolarity  : 1;
    uint32_t SARADC_ANA_EOCPolarity  : 1;
    uint32_t SARADC_ANA_ClkPolarity  : 1;
    uint32_t SARADC_Clock_DCEn       : 1;
    uint32_t SARADC_Chp_DCEn         : 1;
    uint32_t SARADC_Chn_DCEn         : 1;
    uint32_t SARADC_SF_DCEn          : 1;
    uint32_t SARADC_DIFF_DCEn        : 1;
    uint32_t SARADC_ATT_DCEn         : 1;
    uint32_t SARADC_Ref_DCEn         : 1;
    uint32_t rsv_0                   : 1;
    uint32_t SARADC_MAX_Channle      : 4;
    uint32_t SARADC_FIFO_Channel_Sel : 4;
    uint32_t SARADC_FIFO_AFull_Thr   : 6;
    uint32_t SARADC_FIFO_Mode        : 1;
    uint32_t rsv_1                   : 1;
}REG_SARADC_Config_t;

/* Timing Register for SARADC */
typedef struct
{
    uint32_t SARADC_ClkDIV             : 8;
    uint32_t SARADC_Sample_TimeoutCNT  : 4;
    uint32_t SARADC_Convert_TimeoutCNT : 4;
    uint32_t SARADC_CH_Interval_Len    : 16;
}REG_SARADC_Timing_t;

/* WDT Config Register for SARADC */
typedef struct
{
    uint32_t WDT_EN                  : 1;
    uint32_t WDT_Mode                : 1;
    uint32_t rsv_0                   : 2;
    uint32_t WDT_Trigger_Threshold   : 5;
    uint32_t rsv_1                   : 7;
    uint32_t WDT_Monitor_Channel_Sel : 16;
}REG_SARADC_WDT_Config_t;

/* WDT Threshold Register for SARADC */
typedef struct
{
    uint32_t WDT_Min_Limit : 10;
    uint32_t rsv_0         : 6;
    uint32_t WDT_Max_Limit : 10;
    uint32_t rsv_1         : 6;
}REG_SARADC_WDT_Threshold_t;

/* ADC Analog Control0 Register */
typedef struct
{
    uint32_t SARADC_ANA_POWER               : 1;
    uint32_t SARADC_ANA_RSTN                : 1;
    uint32_t SARADC_ANA_ATT_CTL             : 2;
    uint32_t SARADC_ANA_TSAMPLE             : 4;
    uint32_t SARADC_ANA_SF_IS               : 3;
    uint32_t SARADC_ANA_SACLK_CTL           : 1;
    uint32_t SARADC_ANA_CMP_IS              : 4;
    uint32_t SARADC_ANA_IS                  : 4;
    uint32_t SARADC_ANA_VCMI_IS             : 4;
    uint32_t SARADC_ANA_SF_EN               : 1;
    uint32_t SARADC_ANA_SINGLEN_DIFF_MODE   : 1;
    uint32_t SARADC_ANA_REF_SEL             : 2;
    uint32_t SARADC_ANA_PIN_TO_SAMPLE_EN    : 1;
    uint32_t SARADC_ANA_PIN_TO_SAMPLE_EN_IO : 1;
    uint32_t SARADC_ANA_VBAT_DIV_EN         : 1;
    uint32_t SARADC_ANA_TEMP_SENSE_EN       : 1;
}REG_SARADC_ANA_CTRL0_t;

/* ADC Analog Control0 Register */
typedef struct
{
    uint32_t SARADC_ANA_REF_BUF_EN              : 1;
    uint32_t SARADC_ANA_REF_BUF_GAIN            : 2;
    uint32_t rsv_0                              : 1;
    uint32_t SARADC_ANA_REF_BUF_OSTG_IB_MOSSIZE : 4;
    uint32_t SARADC_ANA_CH_PPIN_SEL             : 4;
    uint32_t SARADC_ANA_CH_NPIN_SEL             : 4;
    uint32_t rsv_1                              : 16;
}REG_SARADC_ANA_CTRL1_t;

/* channel Config Register for SARADC */
typedef struct
{
    uint32_t Channelx_Map_P : 4;
    uint32_t Channelx_Map_N : 4;
    uint32_t Channelx_SF    : 1;
    uint32_t Channelx_DIFF  : 1;
    uint32_t Channelx_ATT   : 2;
    uint32_t Channelx_Ref   : 2;
    uint32_t rsv_0          : 11;
}REG_SARADC_Channel_Config_t;

/* ---------------------------------------------------*/
/*                   ADC_pro Register                 */
/* ---------------------------------------------------*/
typedef struct 
{
    volatile REG_SARADC_Control_t        SARADC_Control;             /* Offset 0x00 */
    volatile REG_SARADC_Config_t         SARADC_Config;              /* Offset 0x04 */
    volatile REG_SARADC_Timing_t         SARADC_Timing;              /* Offset 0x08 */
    volatile REG_SARADC_WDT_Config_t     SARADC_WDT0_Config;         /* Offset 0x0C */
    volatile REG_SARADC_WDT_Threshold_t  SARADC_WDT0_Threshold;      /* Offset 0x10 */
    volatile REG_SARADC_WDT_Config_t     SARADC_WDT1_Config;         /* Offset 0x14 */
    volatile REG_SARADC_WDT_Threshold_t  SARADC_WDT1_Threshold;      /* Offset 0x18 */
    volatile uint32_t                    SARADC_INT_Enble;           /* Offset 0x1C */
    volatile uint32_t                    SARADC_INT_Status;          /* Offset 0x20 */
    volatile uint32_t                    SARADC_INT_Raws;            /* Offset 0x24 */
    volatile REG_SARADC_ANA_CTRL0_t      SARADC_ANA_CTRL0;           /* Offset 0x28 */
    volatile REG_SARADC_ANA_CTRL1_t      SARADC_ANA_CTRL1;           /* Offset 0x2C */
    volatile REG_SARADC_Channel_Config_t SARADC_ChannelConfig[16];  /* Offset 0x30 ~ 0x6C */
    volatile uint32_t                    SARADC_ChannelData[16];     /* Offset 0x70 ~ 0xAC */
    volatile uint32_t                    SARADC_ChannelStatus;       /* Offset 0xB0 */
    volatile uint32_t                    SARADC_FIFO_Data;           /* Offset 0xB4 */
}struct_ADCP_t;

#define ADC_PRO_ADDR_BASE    (0x50090100)

#define ADCP                 ((struct_ADCP_t *)ADC_PRO_ADDR_BASE)

/* ################################ Register Section END ################################ */
/**
  * @}
  */


  /** @addtogroup SARADC_Initialization_Config_Section
  * @{
  */
/* ################################ Initialization, Config Section Start ################################ */

typedef enum  
{
    SARADC_CHANNEL_0,
    SARADC_CHANNEL_1,
    SARADC_CHANNEL_2,
    SARADC_CHANNEL_3,
    SARADC_CHANNEL_4,
    SARADC_CHANNEL_5,
    SARADC_CHANNEL_6,
    SARADC_CHANNEL_7,
    SARADC_CHANNEL_8,
    SARADC_CHANNEL_9,
}enum_saradc_channel_t;

/* SARADC channel mapping */
typedef enum  
{
    ADC_CH_MAP_PORTD_7,       /* PortD_7 */
    ADC_CH_MAP_PORTD_6,       /* PortD_6 */
    ADC_CH_MAP_PORTD_5,       /* PortD_5 */
    ADC_CH_MAP_PORTD_4,       /* PortD_4 */
    ADC_CH_MAP_PORTD_3,       /* PortD_3 */
    ADC_CH_MAP_PORTD_2,       /* PortD_2 */
    ADC_CH_MAP_PORTD_1,       /* PortD_1 */
    ADC_CH_MAP_PORTD_0,       /* PortD_0 */
    ADC_CH_MAP_PORTC_1,       /* PortC_1 */
    ADC_CH_MAP_PORTC_0,       /* PortC_0 */
    ADC_CH_MAP_REFINT,        /* ADC reference voltage */
    ADC_CH_MAP_VBAT,          /* Vbat */
    ADC_CH_MAP_VBEN,          /* Core temperature negative */
    ADC_CH_MAP_VBEP,          /* Core temperature positive */
    ADC_CH_MAP_PMU_TEST,      /* PMU test */
    ADC_CH_MAP_VSSA,          /* GND */
}enum_saradc_Channel_Map_t;

/* SARADC reference source */
typedef enum  
{
    SARADC_REF_IOLDO,             /* IOLDO voltage as reference source */
    SARADC_REF_INTERNAL_1P2V,     /* internal 1.2 voltage as reference source */
}enum_saradc_reference_t;

/* SARADC interval mode */
typedef enum  
{
    SARADC_INTVL_DISABLE,   /* interval disable */
    SARADC_INTVL_MODE0,     /* interval mode0: Insert the interval time after the loop is completed */
    SARADC_INTVL_MODE1,     /* interval mode0: The interval time inserted between channels */
}enum_saradc_interval_mode_t;

/* SARADC channel mode */
typedef enum  
{
    SARADC_CH_MODE_SINGLE,          /* single-ended signal */
    SARADC_CH_MODE_DIFFERENTIAL,    /* differential signal */
}enum_saradc_channel_mode_t;

/* SARADC voltage divider */
typedef enum  
{
    SARADC_VOLTAGE_DIVIDER_BYPASS,     // bypass
    SARADC_VOLTAGE_DIVIDER_0P25,       // 1/4 voltage divider
    SARADC_VOLTAGE_DIVIDER_0P5,        // 1/2 voltage divider
}enum_saradc_voltage_divider_t;

/* SARADC wdt index */
typedef enum  
{
    SARADC_WDT0,
    SARADC_WDT1,
}enum_saradc_wdt_t;

/* SARADC wdt work mode */
typedef enum  
{
    SARADC_WDT_MODE0,    /* min <= adc <= max trigger */
    SARADC_WDT_MODE1,    /* adc < min || adc > max trigger */
}enum_saradc_wdt_mode_t;

/* SARADC wdt monitor channel select */
typedef enum  
{
    SARADC_WDT_MONITOR_CH0  = 0x1,
    SARADC_WDT_MONITOR_CH1  = 0x2,
    SARADC_WDT_MONITOR_CH2  = 0x4,
    SARADC_WDT_MONITOR_CH3  = 0x8,
    SARADC_WDT_MONITOR_CH4  = 0x10,
    SARADC_WDT_MONITOR_CH5  = 0x20,
    SARADC_WDT_MONITOR_CH6  = 0x40,
    SARADC_WDT_MONITOR_CH7  = 0x80,
    SARADC_WDT_MONITOR_CH8  = 0x100,
    SARADC_WDT_MONITOR_CH9  = 0x200,
    SARADC_WDT_MONITOR_CH10 = 0x400,
    SARADC_WDT_MONITOR_CH11 = 0x800,
    SARADC_WDT_MONITOR_CH12 = 0x1000,
    SARADC_WDT_MONITOR_CH13 = 0x2000,
    SARADC_WDT_MONITOR_CH14 = 0x4000,
    SARADC_WDT_MONITOR_CH15 = 0x8000,
}enum_saradc_wdt_monitor_channel_t;

/* SARADC function enable/disable select */
typedef enum
{
    SARADC_FUNC_DISABLE,     /*!< function disable */
    SARADC_FUNC_ENABLE,      /*!< function enable  */
}enum_saradc_func_en_t;

/** @defgroup SARADC_interrupt_enable_definition
  * @{
  */
#define SARADC_INT_EN_CHANNEL_VALID            (1 << 0)
#define SARADC_INT_EN_LOOP                     (1 << 1)
#define SARADC_INT_EN_WDT0                     (1 << 2)
#define SARADC_INT_EN_WDT1                     (1 << 3)
#define SARADC_INT_EN_FIFO_ALMOST_FULL         (1 << 4)
#define SARADC_INT_EN_FIFO_FULL                (1 << 5)
#define SARADC_INT_EN_FIFO_EMPTY               (1 << 6)
#define SARADC_INT_EN_CONVERT_ERR              (1 << 7)
/**
  * @}
  */

/** @defgroup SARADC_interrupt_status_definition
  * @{
  */
#define SARADC_INT_STS_CHANNEL_VALID           SARADC_INT_EN_CHANNEL_VALID
#define SARADC_INT_STS_LOOP                    SARADC_INT_EN_LOOP
#define SARADC_INT_STS_WDT0                    SARADC_INT_EN_WDT0
#define SARADC_INT_STS_WDT1                    SARADC_INT_EN_WDT1
#define SARADC_INT_STS_FIFO_ALMOST_FULL        SARADC_INT_EN_FIFO_ALMOST_FULL
#define SARADC_INT_STS_FIFO_FULL               SARADC_INT_EN_FIFO_FULL
#define SARADC_INT_STS_FIFO_EMPTY              SARADC_INT_EN_FIFO_EMPTY
#define SARADC_INT_STS_CONVERT_ERR             SARADC_INT_EN_CONVERT_ERR
/**
  * @}
  */

/** @defgroup SARADC_interrupt_raw_status_definition
 * @{
 */
#define SARADC_INT_RAW_STS_CHANNEL_VALID           SARADC_INT_EN_CHANNEL_VALID
#define SARADC_INT_RAW_STS_LOOP                    SARADC_INT_EN_LOOP
#define SARADC_INT_RAW_STS_WDT0                    SARADC_INT_EN_WDT0
#define SARADC_INT_RAW_STS_WDT1                    SARADC_INT_EN_WDT1
#define SARADC_INT_RAW_STS_FIFO_ALMOST_FULL        SARADC_INT_EN_FIFO_ALMOST_FULL
#define SARADC_INT_RAW_STS_FIFO_FULL               SARADC_INT_EN_FIFO_FULL
#define SARADC_INT_RAW_STS_FIFO_EMPTY              SARADC_INT_EN_FIFO_EMPTY
#define SARADC_INT_RAW_STS_CONVERT_ERR             SARADC_INT_EN_CONVERT_ERR
/**
  * @}
  */

/** @defgroup SARADC_interrupt_clear_status_definition
 * @{
 */
#define SARADC_INT_STS_CLR_LOOP                SARADC_INT_EN_LOOP
#define SARADC_INT_STS_CLR_WDT0                SARADC_INT_EN_WDT0
#define SARADC_INT_STS_CLR_WDT1                SARADC_INT_EN_WDT1
#define SARADC_INT_STS_CLR_CONVERT_ERR         SARADC_INT_EN_CONVERT_ERR
/**
  * @}
  */

  /**
  * @brief  saradc Initialization Structure definition
  */
typedef struct 
{
    uint32_t    saradc_reference;             /*!< Specifies the reference source of channel.
                                                   This parameter can be a value @ref enum_saradc_reference_t */

    uint32_t    saradc_clock_div;             /*!< Specifies the clock divider of saradc.
                                                   This parameter can be a multiple of 2. Max 254 */

    uint32_t    saradc_sampling_cycle;        /*!< Specifies the sampling cycle of saradc.
                                                   This parameter can be a value from 1 to 16 */
}saradc_InitConfig_t;

/**
  * @brief  saradc loop mode configuration parameters.
  */
typedef struct 
{
    uint32_t    loop_max_channel;             /*!< Specifies the MAX channel of loop mode.
                                                   This parameter can be a value from 1 to 16 */

    uint32_t    loop_interval_mode;           /*!< Specifies the interval mode.
                                                   This parameter can be a value @ref enum_saradc_loop_mode_t */
    uint32_t    loop_interval_len;            /*!< Specifies the interval between channels.
                                                   This parameter can be a value from 0 to 0xFFFF */

    uint32_t    loop_FIFO_enable;             /*!< Specifies the FIFO mode of loop mode.
                                                   This parameter can be a value @ref enum_saradc_fifo_mode_t */

    uint32_t    loop_FIFO_channel_sel;        /*!< Specifies the binding channel of fifo.  */
                                                /// loop_FIFO_channel_sel: 0 ~ 15: Select a specified channel
                                                /// loop_FIFO_channel_sel:  >= 16: Select all loop channel

    uint32_t    loop_FIFO_almost_threshold;   /*!< Specifies the almost threshold of fifo. 
                                                   This parameter can be a value from 0 to 64 */
}saradc_LoopConfig_t;

/**
  * @brief  saradc wdt Initialization Structure definition
  */
typedef struct 
{
    uint8_t    saradc_WDT_mode;                 /*!< Specifies the work mode of saradc wdt.
                                                     This parameter can be a value @ref enum_saradc_wdt_mode_t */

    uint16_t   saradc_WDT_monitor_channel;      /*!< Specifies the monitor channel of saradc wdt, multiple channels can be selected.
                                                     This parameter can be a value @ref enum_saradc_wdt_monitor_channel_t */

    uint8_t    saradc_WDT_trigger_threshold;    /*!< Specifies the channel trigger threshold of saradc wdt.
                                                     This parameter can be a value from 1 to 24 */

    uint16_t   saradc_WDT_min_limit;            /*!< Specifies the min limit value of saradc wdt.
                                                     This parameter can be a value from 0 to 0xFFF */

    uint16_t   saradc_WDT_max_limit;            /*!< Specifies the max limit value of saradc wdt.
                                                     This parameter can be a value from 0 to 0xFFF */
}saradc_WdtConfig_t;

/**
  * @brief  saradc channel config Structure definition
  */
typedef struct 
{
    uint32_t    ch_mode;                 /*!< Specifies the reference source of saradc.
                                              This parameter can be a value @ref enum_saradc_channel_mode_t */

    uint32_t    ch_map_p;                /*!< Specifies the positive channel in differential mode, or single-ended mode channel.
                                              This parameter can be a value @ref enum_saradc_Channel_Map_t */
    uint32_t    ch_map_n;                /*!< Specifies the negative channel in differential mode.
                                              This parameter can be a value @ref enum_saradc_Channel_Map_t */

    uint32_t    ch_voltage_divider;      /*!< Specifies Voltage divider of input voltage.
                                              This parameter can be a value @ref enum_saradc_voltage_divider_t */

    uint32_t    ch_source_follower_en;   /*!< Specifies source follower func in differential mode.
                                              This parameter can be a value @ref enum_saradc_func_en_t */
}saradc_ChannelConfig_t;

/* ################################ Initialization, Config Section END ################################## */
/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/

/* SARADC loop mode convert start/stop */
#define __SARADC_LOOP_CONVERT_START()                          (ADCP->SARADC_Control.SARADC_LoopEn = 1)
#define __SARADC_LOOP_CONVERT_STOP()                           (ADCP->SARADC_Control.SARADC_LoopEn = 0)
/* SARADC clock out */
#define __SARADC_CLK_ENABLE()                                  (ADCP->SARADC_Control.SARADC_ClkEn = 1)
#define __SARADC_CLK_DISABLE()                                 (ADCP->SARADC_Control.SARADC_ClkEn = 0)
/* SARADC reset */
#define __SARADC_RESET()                                       (ADCP->SARADC_Control.SARADC_Reset = 1)
#define __SARADC_FIFO_RESET()                                  (ADCP->SARADC_Control.SARADC_FIFO_Reset = 1)
/* SARADC controller select */
#define __SARADC_CONTROLLER_SELECT_ADC()                       (ADCP->SARADC_Control.SARADC_ctrl_sel = 0)
#define __SARADC_CONTROLLER_SELECT_ADCP()                      (ADCP->SARADC_Control.SARADC_ctrl_sel = 1)

/* work mode */
#define __SARADC_WORK_MODE()                                   (ADCP->SARADC_Config.SARADC_OP_Mode = 0)
#define __SARADC_LOOP_MODE_CONFIG(__CFG__)                     (ADCP->SARADC_Config.SARADC_POLL_Mode = __CFG__)
/* interval mode */
#define __SARADC_INTV_MODE(__CFG__)                            (ADCP->SARADC_Config.SARADC_Intv_Mode = __CFG__)
/* SARADC FIFO enable/dsiable */
#define __SARADC_FIFO_ENABLE()                                 (ADCP->SARADC_Config.SARADC_FIFO_En = 1)
#define __SARADC_FIFO_DISABLE()                                (ADCP->SARADC_Config.SARADC_FIFO_En = 0)
/* SARADC DMA enable/dsiable */
#define __SARADC_DMA_ENABLE()                                  (ADCP->SARADC_Config.SARADC_DMA_En = 1)
#define __SARADC_DMA_DISABLE()                                 (ADCP->SARADC_Config.SARADC_DMA_En = 0)
/* SARADC clock polarity */
#define __SARADC_ANA_SOC_POLARITY_CONFIG(__CFG__)              (ADCP->SARADC_Config.SARADC_ANA_SOCPolarity = __CFG__)
#define __SARADC_ANA_EOC_POLARITY_CONFIG(__CFG__)              (ADCP->SARADC_Config.SARADC_ANA_EOCPolarity = __CFG__)
#define __SARADC_ANA_CLOCK_POLARITY_CONFIG(__CFG__)            (ADCP->SARADC_Config.SARADC_ANA_ClkPolarity = __CFG__)
/* SARADC dynamic config */
#define __SARADC_CLOCK_DYNAMIC_CONFIG(__CFG__)                 (ADCP->SARADC_Config.SARADC_Clock_DCEn = __CFG__)
#define __SARADC_CHP_DYNAMIC_CONFIG(__CFG__)                   (ADCP->SARADC_Config.SARADC_Chp_DCEn = __CFG__)
#define __SARADC_CHN_DYNAMIC_CONFIG(__CFG__)                   (ADCP->SARADC_Config.SARADC_Chn_DCEn = __CFG__)
#define __SARADC_SF_DYNAMIC_CONFIG(__CFG__)                    (ADCP->SARADC_Config.SARADC_SF_DCEn = __CFG__)
#define __SARADC_DIFF_DYNAMIC_CONFIG(__CFG__)                  (ADCP->SARADC_Config.SARADC_DIFF_DCEn = __CFG__)
#define __SARADC_ATT_DYNAMIC_CONFIG(__CFG__)                   (ADCP->SARADC_Config.SARADC_ATT_DCEn = __CFG__)
#define __SARADC_REF_DYNAMIC_CONFIG(__CFG__)                   (ADCP->SARADC_Config.SARADC_Ref_DCEn = __CFG__)
/* SARADC loop mode max channel config */
#define __SARADC_LOOP_MODE_MAX_CHANNEL_CONFIG(__CFG__)         (ADCP->SARADC_Config.SARADC_MAX_Channle = __CFG__)
/* SARADC FIFO Select specified channel */
#define __SARADC_FIFO_SELECT_CHANNEL_CONFIG(__CFG__)           (ADCP->SARADC_Config.SARADC_FIFO_Channel_Sel = __CFG__)
/* SARADC FIFO mode config */
#define __SARADC_FIFO_MODE_CONFIG(__CFG__)                     (ADCP->SARADC_Config.SARADC_FIFO_Mode = __CFG__)
/* SARADC FIFO threshold */
#define __SARADC_FIFO_ALMOST_FULL_THRESHOLD_CONFIG(__CFG__)    (ADCP->SARADC_Config.SARADC_FIFO_AFull_Thr = __CFG__)

/* SARADC sampling clock divider */
#define __SARADC_SAMPLING_CLOCK_DIV_CONFIG(__CFG__)            (ADCP->SARADC_Timing.SARADC_ClkDIV = __CFG__)
#define __SARADC_SAMPLING_TIMEOUT_CONFIG(__CFG__)              (ADCP->SARADC_Timing.SARADC_Sample_TimeoutCNT = __CFG__)
#define __SARADC_CONVERT_TIMEOUT_CONFIG(__CFG__)               (ADCP->SARADC_Timing.SARADC_Convert_TimeoutCNT = __CFG__)
#define __SARADC_CHANNEL_INTERVAL_LENGTH_CONFIG(__CFG__)       (ADCP->SARADC_Timing.SARADC_CH_Interval_Len = __CFG__)

/* SARADC interrupt enable/disable */
#define __SARADC_INT_ENABLE(__INTx__)                          (ADCP->SARADC_INT_Enble |= (__INTx__))
#define __SARADC_INT_DISABLE(__INTx__)                         (ADCP->SARADC_INT_Enble &= ~(__INTx__))
/* SARADC get interrupt status */
/* SARADC get interrupt raw status */
#define __SARADC_GET_INT_STATUS()                              (ADCP->SARADC_INT_Status)
#define __SARADC_GET_INT_RAW_STATUS()                          (ADCP->SARADC_INT_Raws)
/* SARADC clear interrupt status */
#define __SARADC_CLR_INT_STATUS(__INTx__)                      (ADCP->SARADC_INT_Status = (__INTx__))

/* SARADC channel config */
#define __SARADC_CHANNEL_MAP_P_CONFIG(__CHx__, __MAP__)              (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_Map_P = __MAP__)
#define __SARADC_CHANNEL_MAP_N_CONFIG(__CHx__, __MAP__)              (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_Map_N = __MAP__)
#define __SARADC_CHANNEL_SOURCE_FOLLOWER_ENABLE(__CHx__)             (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_SF = 1)
#define __SARADC_CHANNEL_SOURCE_FOLLOWER_DISABLE(__CHx__)            (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_SF = 0)
#define __SARADC_CHANNEL_SOURCE_FOLLOWER_CONFIG(__CHx__, __CFG__)    (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_SF = __CFG__)
#define __SARADC_CHANNEL_DIFFERENCE_ENABLE(__CHx__)                  (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_DIFF = 1)
#define __SARADC_CHANNEL_DIFFERENCE_DISABLE(__CHx__)                 (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_DIFF = 0)
#define __SARADC_CHANNEL_DIFFERENCE_CONFIG(__CHx__, __CFG__)         (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_DIFF = __CFG__)
#define __SARADC_CHANNEL_MODE_CONFIG(__CHx__, __CFG__)               (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_DIFF = __CFG__)
#define __SARADC_CHANNEL_ATT_CONFIG(__CHx__, __CFG__)                (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_ATT = __CFG__)
#define __SARADC_CHANNEL_REF_CONFIG(__CHx__, __CFG__)                (ADCP->SARADC_ChannelConfig[__CHx__].Channelx_Ref = __CFG__)

/* SARADC WDT0 config */
#define __SARADC_WDT0_ENABLE()                                 (ADCP->SARADC_WDT0_Config.WDT_EN = 1)
#define __SARADC_WDT0_DISABLE()                                (ADCP->SARADC_WDT0_Config.WDT_EN = 0)
#define __SARADC_WDT0_MODE_CONFIG(__CFG__)                     (ADCP->SARADC_WDT0_Config.WDT_Mode = __CFG__)
#define __SARADC_WDT0_TRIGGER_THRESHOLD_CONFIG(__CFG__)        (ADCP->SARADC_WDT0_Config.WDT_Trigger_Threshold = __CFG__)
#define __SARADC_WDT0_GET_MONITOR_CHANNEL()                    (ADCP->SARADC_WDT0_Config.WDT_Monitor_Channel_Sel)
#define __SARADC_WDT0_MONITOR_CHANNEL_CONFIG(__CFG__)          (ADCP->SARADC_WDT0_Config.WDT_Monitor_Channel_Sel = __CFG__)
#define __SARADC_WDT0_MAX_LIMIT_CONFIG(__CFG__)                (ADCP->SARADC_WDT0_Threshold.WDT_Max_Limit = __CFG__)
#define __SARADC_WDT0_MIN_LIMIT_CONFIG(__CFG__)                (ADCP->SARADC_WDT0_Threshold.WDT_Min_Limit = __CFG__)
/* SARADC WDT1 config */
#define __SARADC_WDT1_ENABLE()                                 (ADCP->SARADC_WDT1_Config.WDT_EN = 1)
#define __SARADC_WDT1_DISABLE()                                (ADCP->SARADC_WDT1_Config.WDT_EN = 0)
#define __SARADC_WDT1_MODE_CONFIG(__CFG__)                     (ADCP->SARADC_WDT1_Config.WDT_Mode = __CFG__)
#define __SARADC_WDT1_TRIGGER_THRESHOLD_CONFIG(__CFG__)        (ADCP->SARADC_WDT1_Config.WDT_Trigger_Threshold = __CFG__)
#define __SARADC_WDT1_GET_MONITOR_CHANNEL()                    (ADCP->SARADC_WDT1_Config.WDT_Monitor_Channel_Sel)
#define __SARADC_WDT1_MONITOR_CHANNEL_CONFIG(__CFG__)          (ADCP->SARADC_WDT1_Config.WDT_Monitor_Channel_Sel = __CFG__)
#define __SARADC_WDT1_MAX_LIMIT_CONFIG(__CFG__)                (ADCP->SARADC_WDT1_Threshold.WDT_Max_Limit = __CFG__)
#define __SARADC_WDT1_MIN_LIMIT_CONFIG(__CFG__)                (ADCP->SARADC_WDT1_Threshold.WDT_Min_Limit = __CFG__)

/* SARADC get channel valid status */
#define __SARADC_GET_CHANNEL_VALID_STATUS()                    (ADCP->SARADC_ChannelStatus)

/* SARADC get channel data */
#define __SARADC_GET_CHANNEL_DATA(__CHx__)                     (ADCP->SARADC_ChannelData[__CHx__])

/* SARADC get fifo data/count */
#define __SARADC_GET_FIFO_DATA()                               (ADCP->SARADC_FIFO_Data)
#define __SARADC_GET_FIFO_COUNT()                              ((ADCP->SARADC_INT_Raws >> 16) & 0x7F)

/* analog */
#define __SARADC_ANA_POWER_ON()                                (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_POWER = 0)
#define __SARADC_ANA_POWER_OFF()                               (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_POWER = 1)
#define __SARADC_ANA_RESET_SET()                               (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_RSTN = 0)
#define __SARADC_ANA_RESET_RELEASE()                           (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_RSTN = 1)
#define __SARADC_IS_ANA_RESET()                                (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_RSTN == 0)
#define __SARADC_ANA_SAMPLING_TIME_CONFIG(__CFG__)             (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_TSAMPLE = __CFG__)
#define __SARADC_ANA_CMP_IS_CONFIG(__CFG__)                    (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_CMP_IS = __CFG__)
#define __SARADC_ANA_SF_IS_CONFIG(__CFG__)                     (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_SF_IS = __CFG__)
#define __SARADC_ANA_IS_CONFIG(__CFG__)                        (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_IS = __CFG__)
#define __SARADC_ANA_VCMI_IS_CONFIG(__CFG__)                   (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_VCMI_IS = __CFG__)
#define __SARADC_ANA_SF_EN_CONFIG(__CFG__)                     (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_SF_EN = __CFG__)
#define __SARADC_ANA_SINGLEN_DIFF_MODE_CONFIG(__CFG__)         (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_SINGLEN_DIFF_MODE = __CFG__)
#define __SARADC_ANA_REF_SEL_CONFIG(__CFG__)                   (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_REF_SEL = __CFG__)
#define __SARADC_ANA_PIN_TO_SAMPLE_EN_CONFIG(__CFG__)          (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_PIN_TO_SAMPLE_EN = __CFG__)
#define __SARADC_ANA_PIN_TO_SAMPLE_EN_IO_CONFIG(__CFG__)       (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_PIN_TO_SAMPLE_EN_IO = __CFG__)
#define __SARADC_ANA_VBAT_DIV_EN_CONFIG(__CFG__)               (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_VBAT_DIV_EN = __CFG__)
#define __SARADC_ANA_TEMP_SENSE_EN_CONFIG(__CFG__)             (ADCP->SARADC_ANA_CTRL0.SARADC_ANA_TEMP_SENSE_EN = __CFG__)

#define __SARADC_ANA_REF_BUF_EN_CONFIG(__CFG__)                (ADCP->SARADC_ANA_CTRL1.SARADC_ANA_REF_BUF_EN = __CFG__)
#define __SARADC_ANA_REF_BUF_GAIN_CONFIG(__CFG__)              (ADCP->SARADC_ANA_CTRL1.SARADC_ANA_REF_BUF_GAIN = __CFG__)
#define __SARADC_ANA_REF_BUF_OSTG_IB_MOSSIZE(__CFG__)          (ADCP->SARADC_ANA_CTRL1.SARADC_ANA_REF_BUF_OSTG_IB_MOSSIZE = __CFG__)

/* Exported functions --------------------------------------------------------*/

/* saradc_init */
void saradc_init(saradc_InitConfig_t *Init);

/* loop mode convert start/stop */
bool saradc_loop_config(saradc_LoopConfig_t *sConfig);
void saradc_loop_convert_start(void);
void saradc_loop_convert_stop(void);

/* wdt config */
void saradc_wdt_config(enum_saradc_wdt_t fe_wdt, saradc_WdtConfig_t *fstr_config);
void saradc_wdt_enable(enum_saradc_wdt_t fe_wdt);
void saradc_wdt_disable(enum_saradc_wdt_t fe_wdt);

/* saradc_get_fifo_count */
/* saradc_get_fifo_data */
uint16_t saradc_get_fifo_count(void);
void saradc_get_fifo_data(uint16_t *fp_data, uint32_t fu32_length);

/* saradc_get_channel_valid_status */
/* saradc_get_channel_data */
bool saradc_get_channel_valid_status(enum_saradc_channel_t fe_channel);
uint16_t saradc_get_channel_data(enum_saradc_channel_t fe_channel);

/* saradc_channel_config */
void saradc_channel_config(enum_saradc_channel_t fe_channel, saradc_ChannelConfig_t *sConfig);

/* saradc_vbe_measure_enable/disable */
void saradc_vbe_measure_enable(void);
void saradc_vbe_measure_disable(void);

/* saradc_vbat_measure_enable/disable */
void saradc_vbat_measure_enable(void);
void saradc_vbat_measure_disable(void);

/* saradc interrupt enable/disable */
/* saradc interrupt get status/clear status */
void saradc_int_enable(uint32_t fu32_INT);
void saradc_int_disable(uint32_t fu32_INT);
void saradc_int_status_clear(uint32_t fu32_INT);
uint32_t saradc_get_int_status(void);
uint32_t saradc_get_int_raw_status(void);

#endif
