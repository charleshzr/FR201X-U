#ifndef _DRIVER_PSRAM_H
#define _DRIVER_PSRAM_H


enum psram_clk_sel_t {
    PSRAM_CLK_SEL_COREH_48M,    // 24MHz
    PSRAM_CLK_SEL_COREH_96M,    // 24MHz
    PSRAM_CLK_SEL_MAX,    
};

void carl_psram_test(void);
bool psram_init(enum psram_clk_sel_t clk_sel);
void psram_cache_enable(void);
#endif /* _DRIVER_PSRAM_H */

