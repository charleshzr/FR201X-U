/*
  ******************************************************************************
  * @file    driver_rgb.h
  * @author  FreqChip Firmware Team
  * @version V1.0.0
  * @date    2024
  * @brief   Header file of RGB HAL module.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 FreqChip.
  * All rights reserved.
  ******************************************************************************
*/
#ifndef __DRIVER_RGB_H__
#define __DRIVER_RGB_H__

#include "stdint.h"
#include "stdbool.h"
#include "plf.h"

/** @addtogroup RGB_Registers_Section
  * @{
  */
/* ################################ Register Section Start ################################ */

/* RGB Configuration */
typedef struct 
{
    uint32_t RGBEN               :1; 
    uint32_t VDPOL               :1;
    uint32_t HDPOL               :1;
    uint32_t DEPOL               :1;
    uint32_t DCLKPOL             :1;
    uint32_t RGB_FORAMAT_OUT     :2; 
    uint32_t RGB_FORMAT_IN       :1;
    uint32_t COL_MAP             :1;
    uint32_t rsv_0               :3;    
    uint32_t PIXEL_CLK_DIV       :4;    
    uint32_t rsv_1               :16;
}REG_RGB_CFG_t;

/* RGB Porch period */
typedef struct 
{
    uint32_t VFP     :8;
    uint32_t VBP     :8;
    uint32_t HFP     :8;
    uint32_t HBP     :8;
}REG_PORCH_PERIOD_t;

/* RGB Display Period */
typedef struct 
{
    uint32_t VRES     :10;
    uint32_t VSPW     :6;
    uint32_t HRES     :10;
    uint32_t HSPW     :6;
}REG_DISPLAY_PERIOD_t;


/* DMA Configuration */
typedef struct 
{
    uint32_t DMA_TX_LEVEL : 5;
    uint32_t DMA_ENABLE   : 1;
    uint32_t rsv_0        : 26;
}REG_RGB_DMA_t;

/* -------------------------------------------*/
/*                RGB Register                */
/* -------------------------------------------*/
typedef struct 
{
    volatile uint32_t                   TX_FIFO;            /* offset 0x00 */ 
    volatile uint32_t                   rsv_0[0x7];        
    volatile REG_RGB_DMA_t              DMA_CFG;            /* offset 0x20 */   
    volatile uint32_t                   rsv_1[0x2];    
    volatile uint32_t                   TXFF_CLR;           /* offset 0x2C */ 
    volatile uint32_t                   rsv_2;
    volatile uint32_t                   FIFO_STS;           /* offset 0x34 */  
    volatile uint32_t                   rsv_3[0x3];    
    volatile REG_RGB_CFG_t              RGB_CFG;            /* offset 0x44 */ 
    volatile REG_DISPLAY_PERIOD_t       DISPLAY_PERIOD;     /* offset 0x48 */     
    volatile REG_PORCH_PERIOD_t         PORCH_PERIOD;       /* offset 0x4C */
}struct_RGB_t;

#define RGB              ((volatile struct_RGB_t *)LCD_BASE)

/* ################################ Register Section END ################################ */
/**
  * @}
  */



/** @addtogroup RGB_Initialization_Config_Section
  * @{
  */
/* ################################ Initialization、Config Section Start ################################ */

/* FIFO STATUS */
typedef enum
{
    TXFIFO_FULL     = 0x00000002,
    TXFIFO_EMPT     = 0x00000008,
    FRAME_END       = 0x00002000,
}enum_FIFO_STATUS_t;

/* INT STATUS */
typedef enum
{
    FRAME_END_EN    = 0x00001000,
}enum_INT_STATUS_t;

/* RGB FORMAT */
typedef enum
{
    RGB888_OUT,
    RGB666_OUT,
    RGB565_OUT,
}enum_RGB_OUT_FORMAT_SELECT_t;

/* RGB FORMAT */
typedef enum
{
    RGB888_IN,
    RGB565_IN,
}enum_RGB_IN_FORMAT_SELECT_t;

/**
  * @brief  Display RGB Initialization Structure definition
  */
typedef struct 
{
    uint32_t PixelClock_Prescaler;      /* This parameter can becan be a 5bit value */
    
    uint32_t RGB_OUT_FORMAT_SELECT;     /* This parameter can be a value of @ref enum_RGB_OUT_FORMAT_SELECT_t */  
    
    uint32_t RGB_IN_FORMAT_SELECT;      /* This parameter can be a value of @ref enum_RGB_IN_FORMAT_SELECT_t */   
        
    uint32_t HBP;                       /* This parameter can becan be a 8bit value */
    
    uint32_t HFP;                       /* This parameter can becan be a 8bit value */  

    uint32_t VBP;                       /* This parameter can becan be a 8bit value */
    
    uint32_t VFP;                       /* This parameter can becan be a 8bit value */ 

    uint32_t HRES;                      /* This parameter can becan be a 12bit value */ 
    
    uint32_t VRES;                      /* This parameter can becan be a 12bit value */ 
    
    uint32_t HSPW;                      /* This parameter can becan be a 6bit value */ 
    
    uint32_t VSPW;                      /* This parameter can becan be a 6bit value */    
    
}RGB_InitTypeDef;

/* ################################ Initialization、Config Section END ################################ */
/**
  * @}
  */

/* RGB Pixel Clk polarity */ 
#define __RGB_SET_PIXEL_CLK_POLARITY_HIGH()                                      (RGB->RGB_CFG.DCLKPOL = 1)
#define __RGB_SET_PIXEL_CLK_POLARITY_LOW()                                       (RGB->RGB_CFG.DCLKPOL = 0)

/* RGB VSYNC polarity */ 
#define __RGB_SET_VSYNC_POLARITY_HIGH()                                          (RGB->RGB_CFG.VDPOL = 1)
#define __RGB_SET_VSYNC_POLARITY_LOW()                                           (RGB->RGB_CFG.VDPOL = 0)  
#define __RGB_SET_HSYNC_POLARITY_HIGH()                                          (RGB->RGB_CFG.HDPOL = 1)
#define __RGB_SET_HSYNC_POLARITY_LOW()                                           (RGB->RGB_CFG.HDPOL = 0)                                                                                              
#define __RGB_SET_DE_POLARITY_HIGH()                                             (RGB->RGB_CFG.DEPOL = 0)
#define __RGB_SET_DE_POLARITY_LOW()                                              (RGB->RGB_CFG.DEPOL = 1) 

/* RGB Enable and Disable */                                                                                             
#define __RGB_ENABLE()                                                           (RGB->RGB_CFG.RGBEN = 1)  
#define __RGB_DISABLE()                                                          (RGB->RGB_CFG.RGBEN = 0)   

/* RGB Pixel Clk Div */                                                                                             
#define __RGB_SET_PIXEL_CLK_DIV(__CLKDIV__)                                      (RGB->RGB_CFG.PIXEL_CLK_DIV = __CLKDIV__) 

/* RGB tx fifo reset */
/* RGB tx fifo release */
#define __RGB_TX_FIFO_RESET()                                                    (RGB->TXFF_CLR = 0x03)
#define __RGB_TX_FIFO_RELEASE()                                                  (RGB->TXFF_CLR = 0x00)

/* RGB dma requset level */                                                      /* fu8_level: 0 ~ 31 */
#define __RGB_DMA_TX_LEVEL(__LEVEL__)                                            (RGB->DMA_CFG.DMA_TX_LEVEL = __LEVEL__)

/* RGB dma ENABLE and DISABLE */
#define __RGB_DMA_ENABLE()                                                       (RGB->DMA_CFG.DMA_ENABLE = 1)   
#define __RGB_DMA_DISABLE()                                                      (RGB->DMA_CFG.DMA_ENABLE = 0) 

/* RGB get fifo status */
#define __RGB_FIFO_STATUS()                                                      (RGB->FIFO_STS)  

/* RGB INT STATUS Enable and Disable */
#define __RGB_INT_STATUS_ENABLE(__STATUS__)                                      (RGB->FIFO_STS |=  (__STATUS__))  
#define __RGB_INT_STATUS_DISABLE(__STATUS__)                                     (RGB->FIFO_STS &= ~(__STATUS__))  

/* Exported functions --------------------------------------------------------*/

/* rgb_init */
void rgb_init(RGB_InitTypeDef *RGB_Init);

/* rgb_write_data */
void rgb_write_data(RGB_InitTypeDef *RGB_Init, void *fp32_WriteBuffer, uint32_t fu32_WriteNum);


/* Exported inline functions --------------------------------------------------------*/

/* rgb_init */
void rgb_init(RGB_InitTypeDef *RGB_Init);

/* rgb_write_data */
void rgb_write_data(RGB_InitTypeDef *RGB_Init, void *fp32_WriteBuffer, uint32_t fu32_WriteNum);

#endif
