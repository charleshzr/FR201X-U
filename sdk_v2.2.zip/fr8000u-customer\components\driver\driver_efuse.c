/*
  ******************************************************************************
  * @file    driver_efuse.c
  * @author  FreqChip Firmware Team
  * @version V1.0.0
  * @date    2021
  * @brief   eFuse module driver.
  *          This file provides firmware functions to manage the eFuse.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2021 FreqChip.
  * All rights reserved.
  ******************************************************************************
*/
#include "driver_efuse.h"
#include "driver_pmu.h"
#include "sys_utils.h"

/************************************************************************************
 * @fn      eFuse_read
 *
 * @brief   read eFuse data. total of 128-bit
 *
 * @param   fp_Data: read data buffer.
 */
void eFuse_read(uint32_t *fp_Data)
{ 
    /* eFuse clock enable */
    __SYSTEM_EFUSE_CLK_ENABLE();

    /* config read mode */
    EFUSE->eFuse_Ctrl = EFUSE_READ_MODE;
    /* wait config done */
    while(!(EFUSE->eFuse_Ctrl & EFUSE_CHECK_DONE));
    /* read data */
    fp_Data[0] = EFUSE->eFuse_Data0;
    fp_Data[1] = EFUSE->eFuse_Data1;
    fp_Data[2] = EFUSE->eFuse_Data2;
    fp_Data[3] = EFUSE->eFuse_Data3;
}

static uint8_t eFuse_xor_bits(const uint32_t *w, uint8_t from, uint8_t to)
{
    uint8_t xor_v = 0;
    uint8_t i;

    for (i = from; i <= to; i++)
        xor_v ^= (uint8_t)((w[i / 32] >> (i % 32)) & 0x01);

    return xor_v;
}

/************************************************************************************
 * @fn      eFuse_write_new
 *
 * @brief   Write new eFuse bank. Only burn bits that need 0->1,
 *          then read back and verify.
 *
 * @param   w0~w3 : target final values of Data0~Data3.
 *
 * @return  true: success, false: verify fail.
 */
static bool eFuse_write_new(uint32_t w0, uint32_t w1, uint32_t w2, uint32_t w3)
{
    uint32_t cur[4];
    uint32_t burn[4];
    uint32_t expect[4];
    uint32_t tgt[4];
    uint32_t misc_bak;
    uint8_t i;
    uint8_t any = 0;

    tgt[0] = w0;
    tgt[1] = w1;
    tgt[2] = w2;
    tgt[3] = w3;

    /* select new eFuse controller */
    misc_bak = *(volatile uint32_t *)0x50000010;
    *(volatile uint32_t *)0x50000010 = misc_bak | (1u << 5);

    eFuse_read(cur);

    /* calculate bits that need to be burned */
    for (i = 0; i < 4; i++)
    {
        burn[i] = tgt[i] & ~cur[i];
        expect[i] = cur[i] | burn[i];
        if (burn[i] != 0)
            any = 1;
    }

    if (any == 0)
    {
        *(volatile uint32_t *)0x50000010 = misc_bak;
        return true;
    }

    /* enable eFuse HV, set IOLDO to 2.7V */
    ool_write(PMU_REG_IOLDO_CFG_2, ool_read(PMU_REG_IOLDO_CFG_2) | (1 << 6));
    pmu_ioldo_voltage(PMU_ALDO_2_7V);
    co_delay_100us(1);

    EFUSE->eFuse_Data0 = burn[0];
    EFUSE->eFuse_Data1 = burn[1];
    EFUSE->eFuse_Data2 = burn[2];
    EFUSE->eFuse_Data3 = burn[3];
    EFUSE->eFuse_Ctrl = EFUSE_WRITE_MODE;
    while (!(EFUSE->eFuse_Ctrl & EFUSE_CHECK_DONE));

    /* disable eFuse HV, restore IOLDO to 3.3V */
    ool_write(PMU_REG_IOLDO_CFG_2, ool_read(PMU_REG_IOLDO_CFG_2) & ~(1 << 6));
    pmu_ioldo_voltage(PMU_ALDO_3_3V);
    co_delay_100us(1);

    eFuse_read(cur);
    *(volatile uint32_t *)0x50000010 = misc_bak;

    for (i = 0; i < 4; i++)
    {
        if ((cur[i] & expect[i]) != expect[i])
            return false;
    }

    return true;
}

/************************************************************************************
 * @fn      eFuse_swd_lock
 *
 * @brief   Lock SWD by setting new eFuse bit118.
 *          Checksum: XOR[125:81] must equal XOR[127:126].
 *          Only allow 0->1; prefer burn bit126, else bit127.
 *
 * @return  true: success, false: fail.
 */
bool eFuse_swd_lock(void)
{
    uint32_t cur[4];
    uint32_t tgt[4];
    uint32_t misc_bak;
    uint8_t i;

    /* select new eFuse controller */
    misc_bak = *(volatile uint32_t *)0x50000010;
    *(volatile uint32_t *)0x50000010 = misc_bak | (1u << 5);
    eFuse_read(cur);
    *(volatile uint32_t *)0x50000010 = misc_bak;

    /* already locked, skip burn */
    if (((cur[3] >> 22) & 0x01) != 0)
        return true;

    for (i = 0; i < 4; i++)
        tgt[i] = cur[i];
    tgt[3] |= (1u << 22);    /* bit118 */

    /* XOR[125:81] == XOR[127:126]; only allow 0->1 */
    if (eFuse_xor_bits(tgt, 81, 125) != eFuse_xor_bits(tgt, 126, 127))
    {
        if (((tgt[3] >> 30) & 0x01) == 0)
            tgt[3] |= (1u << 30);    /* bit126 */
        else if (((tgt[3] >> 31) & 0x01) == 0)
            tgt[3] |= (1u << 31);    /* bit127 */
        else
            return false;
    }

    if (eFuse_write_new(tgt[0], tgt[1], tgt[2], tgt[3]) == false)
        return false;

    *(volatile uint32_t *)0x50000010 = misc_bak | (1u << 5);
    eFuse_read(cur);
    *(volatile uint32_t *)0x50000010 = misc_bak;

    if (((cur[3] >> 22) & 0x01) == 0)
        return false;
    if (eFuse_xor_bits(cur, 81, 125) != eFuse_xor_bits(cur, 126, 127))
        return false;

    return true;
}
